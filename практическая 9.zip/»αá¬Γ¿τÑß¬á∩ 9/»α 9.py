f = open('Tuchina D.A_UB-22_vvod.tx.txt', 'rt')    
M2 = []
i = 0
for line in f:
    lines = line.split(' ')
    lst = []
    for ln in lines:
        ln = ln.rstrip()

        if ln != '':
            num = int(ln)
            lst = lst + [num]
    M2 = M2 + [lst]               #MATRIX WITH FILE
a, b = 1, 0
M2[4//2][4//2]=4*4                #центр матрицы
for v in range(4//2):             #верхняя горизонталь матрицы
    for i in range(4-b):
        M2[v][i+v] = a
        a+=1
    for i in range(v+1, 4-v):      #правая вертикаль матрицы
        M2[i][-v-1] = a
        a+=1
    for i in range(v+1, 4-v):      #нижняя горизонталь матрицы
        M2[-v-1][-i-1] =a
        a+=1
    for i in range(v+1, 4-(v+1)):  #левая вертикаль матрицы
        M2[-i-1][v]=a
        a+=1
    b+=2
for i in M2:
    print(*i)
f.close()
f1 = open('Tuchina D.A_UB-22_vivod.tx.txt', 'w')   #ZAPIS V FILE
y = 0
while y < 4:                       #цикл по строкам
    j = 0
    while j < 4:                   #цикл по столбцам
        s = str(M2[y][j])
        f1.write(s + ' ')
        j = j+1
    f1.write('\n')
    y = y + 1
f1.close()
