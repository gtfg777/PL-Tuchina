import tkinter as tk
from tkinter import *
from tkinter import messagebox
import json

def write():
    if repository.get() == "jlippold":
        with open("data.txt",'w',encoding='utf-8') as file:
            json.dump(data_2,file,indent=4)
        messagebox.showinfo('Save', 'File saved as data')
    elif len(repository.get()) == 0 :
        messagebox.showerror('Error', 'Enter repository ')
    else:
        messagebox.showerror('Error', 'Try again!  Repository is not found')


str_json="""
{
  "login": "jlippold",
  "id": 1939514,
  "node_id": "MDQ6VXNlcjE5Mzk1MTQ=",
  "avatar_url": "https://avatars.githubusercontent.com/u/1939514?v=4",
  "gravatar_id": "",
  "url": "https://api.github.com/users/jlippold",
  "html_url": "https://github.com/jlippold",
  "followers_url": "https://api.github.com/users/jlippold/followers",
  "following_url": "https://api.github.com/users/jlippold/following{/other_user}",
  "gists_url": "https://api.github.com/users/jlippold/gists{/gist_id}",
  "starred_url": "https://api.github.com/users/jlippold/starred{/owner}{/repo}",
  "subscriptions_url": "https://api.github.com/users/jlippold/subscriptions",
  "organizations_url": "https://api.github.com/users/jlippold/orgs",
  "repos_url": "https://api.github.com/users/jlippold/repos",
  "events_url": "https://api.github.com/users/jlippold/events{/privacy}",
  "received_events_url": "https://api.github.com/users/jlippold/received_events",
  "type": "User",
  "site_admin": false,
  "name": "Jed Lippold",
  "company": null,
  "blog": "https://jed.bz",
  "location": null,
  "email": null,
  "hireable": null,
  "bio": null,
  "twitter_username": null,
  "public_repos": 54,
  "public_gists": 0,
  "followers": 127,
  "following": 0,
  "created_at": "2012-07-08T20:45:45Z",
  "updated_at": "2022-07-15T13:05:23Z"
}
"""
str_json1="""
{
"company": null,
"created_at": "2012-07-08T20:45:45Z",
"email": null,
"id": 1939514,
"name": "Jed Lippold",
"url": "https://api.github.com/users/jlippold"
}"""
data_2 = json.loads(str_json1)
win = Tk()
win.geometry(f"300x250+100+200")
win['bg'] ='#99ff99'
win.title('JSON')
repository = StringVar()
lbl = Label(win, text="ENTER REPOSITORY(jlippold)",bg="#99ff99",fg='#013220')                #viget is name
lbl.grid(column=250, row=250)
lbl.place(x=150, y=60,width=170, height=160,anchor=CENTER)
vvod = Entry(win,textvariable=repository)                                                                #pole vvoda
vvod.place(x=20, y=100, width=210, height=20)
Enter = Button(win,text = 'Enter',bg='#00ff7f',fg='#013220',activebackground='#013220',      #knopka enter
          activeforeground='#00ff7f',command=write)
Enter.place(x=235, y=100, width=50, height=20)
tk.Button(text = 'Save',bg='#00ff7f',fg='#013220',activebackground='#013220',      #knopka save
        activeforeground='#00ff7f').place(x=120, y=150, width=50, height=20)

win.mainloop()

